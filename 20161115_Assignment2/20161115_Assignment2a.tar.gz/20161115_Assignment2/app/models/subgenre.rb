class Subgenre < ApplicationRecord
end
