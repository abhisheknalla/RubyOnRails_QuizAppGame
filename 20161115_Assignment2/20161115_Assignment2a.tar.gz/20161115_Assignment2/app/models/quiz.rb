class Quiz < ApplicationRecord
end
