class Newstate < ApplicationRecord
end
