class Exam < ApplicationRecord
end
