module NewstatesHelper
end
