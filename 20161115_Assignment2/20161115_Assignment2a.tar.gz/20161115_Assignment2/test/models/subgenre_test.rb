require 'test_helper'

class SubgenreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
