require 'test_helper'

class NewstateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
