require "application_system_test_case"

class NewstatesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit newstates_url
  #
  #   assert_selector "h1", text: "Newstate"
  # end
end
