require "application_system_test_case"

class ExamsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit exams_url
  #
  #   assert_selector "h1", text: "Exam"
  # end
end
