require "application_system_test_case"

class SubgenresTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit subgenres_url
  #
  #   assert_selector "h1", text: "Subgenre"
  # end
end
