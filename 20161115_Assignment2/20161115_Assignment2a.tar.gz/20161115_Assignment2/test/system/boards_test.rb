require "application_system_test_case"

class BoardsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit boards_url
  #
  #   assert_selector "h1", text: "Board"
  # end
end
